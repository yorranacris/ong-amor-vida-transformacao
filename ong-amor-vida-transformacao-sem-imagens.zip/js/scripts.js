document.addEventListener('DOMContentLoaded',()=>{
  const ano=new Date().getFullYear();
  document.querySelectorAll('#ano').forEach(e=>e.textContent=ano);
  const form=document.getElementById('form-cadastro');
  if(form){form.addEventListener('submit',e=>{e.preventDefault();alert('Cadastro enviado com sucesso!');form.reset();});}
});