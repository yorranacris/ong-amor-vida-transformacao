# 🌍 Amor, Vida e Transformação

Plataforma web desenvolvida como entrega da Unidade 1 — Projeto Integrador Front-End.

## 🎯 Objetivo
Fornecer uma presença digital profissional para ONGs, permitindo divulgação de projetos, captação de recursos e engajamento de voluntários e doadores.

## 📂 Estrutura
- `index.html`: Página inicial com missão, visão e contato.
- `projetos.html`: Apresenta os projetos sociais e formas de ajuda.
- `cadastro.html`: Formulário completo para voluntários e doadores.
- `style.css`: Estilos com paleta lilás, azul e branco.
- `script.js`: Validação e alertas interativos.

## 🚀 Publicação
Disponível em: [https://yorranacris.github.io/ong-amor-vida-transformacao/](https://yorranacris.github.io/ong-amor-vida-transformacao/)

## ✅ Checklist W3C + Acessibilidade
- Estrutura semântica completa (header, nav, main, section, article, footer)
- Hierarquia de títulos consistente
- Formulários com rótulos acessíveis
- Validação nativa de HTML5
- Cores com contraste adequado
- Código validado pelo W3C Validator
