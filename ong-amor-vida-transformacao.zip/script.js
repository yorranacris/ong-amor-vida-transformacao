document.getElementById('cadastroForm').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Cadastro enviado com sucesso!');
    this.reset();
});